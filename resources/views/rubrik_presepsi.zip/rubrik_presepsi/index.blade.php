@extends('layouts.app')

@section('content')
<div class="card shadow mb-4 m-2">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Rubrik Skala Presepsi</h6>
        @can('presepsi.create')
        <button class="btn btn-primary float-right" id="btn-add" data-toggle="modal" data-target="#rubrikModal">Tambah Rubrik</button>
        @endcan
    </div>
    <div class="card-body">
        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Aspek</th>
                        <th>Skor</th>
                        <th>Grade</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $counter = ($rubrikSkalaPresepsis->currentPage() - 1) * $rubrikSkalaPresepsis->perPage() + 1;
                    @endphp
                    @foreach($rubrikSkalaPresepsis as $rubrik)
                    <tr>
                        <td>{{ $counter++ }}</td>
                        <td>{{ $rubrik->aspek }}</td>
                        <td>{{ $rubrik->skor }}</td>
                        <td>{{ $rubrik->grade }}</td>
                        <td>
                            @can('presepsi.edit')
                            <a href="#" class="btn btn-info btn-sm btn-edit-rubrik" data-id="{{ $rubrik->id }}" data-aspek="{{ $rubrik->aspek }}" data-skor="{{ $rubrik->skor }}" data-grade="{{ $rubrik->grade }}" data-toggle="modal" data-target="#rubrikModal"><i class="fa fa-pencil-alt"></i></a>
                            @endcan
                            @can('presepsi.delete')
                            <a href="#" class="btn btn-danger btn-sm btn-delete-rubrik" data-id="{{ $rubrik->id }}"><i class="fas fa-trash"></i></a>
                            @endcan
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah/Edit Rubrik -->
<div class="modal fade" id="rubrikModal" tabindex="-1" aria-labelledby="rubrikModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rubrikModalLabel">Tambah Rubrik</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="frm-rubrik" method="post" action="{{ route('rubrik_presepsi.store') }}">
                @csrf
                <input type="hidden" name="_method" id="_method-rubrik" value="POST">
                <div class="modal-body">
                    <div>
                        <label>Aspek</label>
                        <input type="text" name="aspek" id="aspek" class="form-control">
                    </div>
                    <div>
                        <label>Skor</label>
                        <input type="text" name="skor" id="skor" class="form-control">
                    </div>
                    <div>
                        <label>Grade</label>
                        <input type="text" name="grade" id="grade" class="form-control">
                    </div>
                    <!-- Deskripsi tambahan -->
                    <div>
                        <label>Deskripsi</label>
                        <textarea name="deskripsi" id="deskripsi" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Konfirmasi Hapus Rubrik -->
<div class="modal fade" id="deleteRubrikModal" tabindex="-1" aria-labelledby="deleteRubrikModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteRubrikModalLabel">Konfirmasi Hapus</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus rubrik ini?
                <input type="hidden" id="deleteRubrikId">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="confirmDeleteRubrik">Hapus</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>

<div class="d-flex justify-content-center my-4">
    {{ $rubrikSkalaPresepsis->links() }}
</div>

@endsection

@push('js')
<script>
    $(function() {
        $('#btn-add').on('click', function() {
            $('#rubrikModalLabel').text('Tambah Rubrik');
            $('#frm-rubrik')[0].reset();
            $('#_method-rubrik').val('POST');
            $('#frm-rubrik').attr('action', '{{ route('rubrik_presepsi.store') }}');
        });

        $('.btn-edit-rubrik').on('click', function() {
            const rubrikId = $(this).data('id');
            const rubrikAspek = $(this).data('aspek');
            const rubrikSkor = $(this).data('skor');
            const rubrikGrade = $(this).data('grade');

            $('#aspek').val(rubrikAspek);
            $('#skor').val(rubrikSkor);
            $('#grade').val(rubrikGrade);
            $('#_method-rubrik').val('PUT');
            $('#frm-rubrik').attr('action', '{{ url("rubrik_presepsi") }}/' + rubrikId);

            $('#rubrikModalLabel').text('Edit Rubrik');
        });

        $('.btn-delete-rubrik').on('click', function() {
            const rubrikId = $(this).data('id');
            $('#deleteRubrikId').val(rubrikId);
            $('#deleteRubrikModal').modal('show');
        });

        $('#confirmDeleteRubrik').on('click', function() {
            const rubrikId = $('#deleteRubrikId').val();
            $.ajax({
                url: '{{ url("rubrik_presepsi") }}/' + rubrikId,
                method: 'DELETE',
                data: { _token: '{{ csrf_token() }}' },
                success: function() {
                    location.reload();
                },
                error: function(xhr, status, error) {
                    console.error("Terjadi kesalahan:", error);
                }
            });
        });
    });
</script>
@endpush
